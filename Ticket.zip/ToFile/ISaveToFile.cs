﻿using System.Text;

namespace OnlineSharp
{
    interface ISaveToFile
    {
        StringBuilder GetString();
    }
}
